import requests
import base64
import cv2 as cv


# opencv 图片
def vehicle_detect(img):
    request_url1 = "https://aip.baidubce.com/rest/2.0/image-classify/v1/body_attr"
    request_url2="https://aip.baidubce.com/rest/2.0/image-classify/v1/body_num"
    #request_url = " https: // aip.baidubce.com / rest / 2.0 / image - classify / v1 / driver_behavior"

    _, encoded_image = cv.imencode('.jpg', img)
    base64_image = base64.b64encode(encoded_image)
    params = {"image":base64_image}
    access_token = '24.233c434618ec87c81e3be8919859fc64.2592000.1722775509.282335-90556278'
    request_url1 = request_url1 + "?access_token=" + access_token
    request_url2=request_url2+"?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url1, data=params, headers=headers)
    response2=requests.post(request_url2, data=params, headers=headers)
    num = 0
    if response2:
        data2 = response2.json()
        num=data2['person_num']
    if response:
        data = response.json()
        for item in data['person_info']:
            location = item['location']
            x1 = location['left']
            y1 = location['top']
            x2 = x1 + location['width']
            y2 = y1 + location['height']
            cv.rectangle(img,(x1,y1),(x2,y2),(0,0,255),2)
        # 定义要绘制的文字
            text = item['attributes']['face_mask']['name']
            if(text=="戴口罩"):
                text="yes"
            else:
                text="unkonw"
            position = (x1, y1-2)
            font = cv.FONT_HERSHEY_SIMPLEX
            font_scale = 1
            color = (0, 0, 255)  # 红色
            thickness = 2
            img = cv.putText(img, text, position, font, font_scale, color, thickness, cv.LINE_AA)
            # cv.imshow('Rectangle', img)
            # return img
    return img, num
    # # 等待按键，然后关闭窗口
    # cv.waitKey(0)
    # cv.destroyAllWindows()
